import requests
import json
import time



def login() :

	with open('./config/login.json') as json_login :
		login = json.load(json_login)

	with open('./config/headers.json') as json_headers :
		headers = json.load(json_headers)

	header = {
		'content-type': headers['content-type'],
		'Origin': headers['Origin'],
		'Referer': headers['Referer'],
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'
	}

	payload = {
		'EmailAddress':login['Username'],
		'Password': login['Password']
	}

	with requests.Session() as session :
		session.post(login['login_url'],data=payload, headers=header)
	print("arushi")
	return session
