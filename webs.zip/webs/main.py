import requests
import json
import time
from simulate import *
from login import *

with open('./dataset/USA.json') as json_usa :
		usa = json.load(json_usa)

with open('./dataset/EUR.json') as json_eur :
		eur = json.load(json_eur)

with open('./dataset/CHN.json') as json_chn :
		chn = json.load(json_chn)

with open('./dataset/ASI.json') as json_asi :
		asi = json.load(json_asi)


session = login()

with open('./code.txt',"r") as file :
	raw_code = file.read()


dataset = eur['fundamental']

for i in dataset :
	code = raw_code.replace("@",i)
	print ("Code : " + code)
	print (simulate(session,code,'EUR','TOP1200',bool_print = True))
