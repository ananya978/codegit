import requests
import json
import time
import pandas as pd
import numpy as np


def simulate(session,code,region,universe,bool_print = False) :
	with open('./config/simulate.json') as json_simulate :
		sim = json.load(json_simulate)

	with open('./config/headers.json') as json_headers :
		headers = json.load(json_headers)

	with open('./config/settings.json') as json_setting :
		setting = json.load(json_setting)

	header = {
		'content-type': headers['content-type'],
		'Origin': headers['Origin'],
		'Referer': headers['Referer'],
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'
	}


	args = '[{"nanhandling":"' + setting['nanhandling'] + '","delay":"1","unitcheck":"off","pasteurize":"on","univid":"' + universe +'","opcodetype":"FLOWSEXPR",\
			"opassetclass":"EQUITY","unithandling":"verify","optrunc":0.08,"code":"'+ code + '","region":"' + region + '","opneut":"' + setting['opneut'] + '",\
			"IntradayType":null,"tags":"equity","decay":'+ setting['decay'] +',"dataviz":"0","backdays":25,"simtime":"Y10"}]'

	code = {
	'args' : args
	}

	result   = session.post(sim['simulate_url'] , data=code , headers=header)
	alpha_id = json.loads(result.content)['result'][0]

	while True :
		response = session.post(sim['progress_url'] + str(alpha_id) ,headers=header)

		if bool_print == True :
			print ("Percentage Progress : " + str(response.json()))

		if str(response.json()) == "DONE" :
			break

		if str(response.json()) == "ERROR" :
			break

		time.sleep(10)

	if str(response.json()) == "DONE" :
		issummary = session.post(sim['issum_url'] + str(alpha_id),headers=header)
		is_table = json.loads(issummary.content)
		values   = is_table['result']

		stats = np.zeros((12,7))
		exit = 0

		for i in range (0,12) :
			if values[i]['YearId'] == "TOTAL" :
				year = 9999
				exit = 1
			else :
				year = values[i]['YearId']

			stats[i][0] = year
			stats[i][1] = values[i]['Sharpe']
			stats[i][2] = values[i]['TurnOver']
			stats[i][3] = values[i]['Returns']
			stats[i][4] = values[i]['Margin']
			stats[i][5] = values[i]['Fitness']
			stats[i][6] = values[i]['DrawDown']

			if exit == 1 :
				break

		stat = pd.DataFrame(stats, columns=["Year", "Sharpe", "TurnOver" , "Returns" , "Margin" , "Fitness" , "DrawDown"])
		return stat

	
	else :
		print ("Error")
		return 

